DUA APLIKASI WEB UNTUK TUGAS DKP

1. teman_kuliah_ai.html — dashboard tugas mahasiswa, AI Tutor (opsional Gemini API), pembuat latihan.
2. quizpop_game_kuis.html — game kuis pilihan ganda dengan 4 kategori, skor, pembahasan, dan rekap hasil.

CARA MENJALANKAN:
- Ekstrak ZIP.
- Klik dua kali file HTML untuk membukanya di Chrome/Edge.
- TemanKuliah AI dapat digunakan untuk mencatat tugas tanpa API key; fitur AI generatif memerlukan Gemini API key.
- QuizPop berjalan langsung tanpa login atau API.

Teknologi: HTML, CSS, JavaScript, LocalStorage (TemanKuliah AI), kuis interaktif berbasis JavaScript.
